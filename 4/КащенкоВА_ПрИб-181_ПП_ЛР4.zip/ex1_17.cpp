#include <stdio.h>
#include <omp.h>

int main()
{
	int count, num;
	double start_time, end_time, time;
    start_time = omp_get_wtime();
    #pragma omp parallel
    {
        count=omp_get_num_threads();
		num=omp_get_thread_num();
		if (num == 0) printf("Всего нитей: %d\n", count);
		else printf("Нить номер %d\n", num);
    }
    // время окончания работы параллельной секции
    end_time = omp_get_wtime();
    // время работы параллельной секции
    time = end_time-start_time;
    printf("Время работы параллельной секции: %f\n", time);	
}

