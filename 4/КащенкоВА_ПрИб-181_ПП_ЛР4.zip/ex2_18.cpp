#include <stdio.h>
#include <omp.h>
#include <malloc.h>
#include <stdlib.h>

int main()
{
	#ifdef _OPENMP
		int i, n;
		int *A = static_cast<int *>(malloc(10000000 * sizeof(int)));
		int *B = static_cast<int *>(malloc(10000000 * sizeof(int)));
		int *C = static_cast<int *>(malloc(10000000 * sizeof(int)));
		
		
		/* Заполним исходные массивы */
		for (i = 0; i < 10000000; i++)
		{
			A[i] = i;
			B[i] = 2 * i;
			C[i] = 0;
		}
		double start_time, end_time, time;
		start_time = omp_get_wtime();
		#pragma omp parallel shared(A, B, C) private(i, n)
		{
			/* Получим номер текущей нити */
			n = omp_get_thread_num();
			#pragma omp for
			for (i = 0; i < 10000000; i++)
			{
				C[i] = A[i] + B[i];
				//printf("Нить %d сложила элементы с номером %d\n", n, i);
			}
		}
		// время окончания работы параллельной секции
    	end_time = omp_get_wtime();
    	free(A);
		free(B);
		free(C);
    	// время работы параллельной секции
    	time = end_time-start_time;
    	printf("Время работы параллельной секции: %f\n", time);
	#else
		printf ("Последовательная версия, демонстрация параллелизма невозможна\n");	
	#endif
}
