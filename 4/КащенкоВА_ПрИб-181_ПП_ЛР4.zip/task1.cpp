#include <stdio.h>
#include <omp.h>
#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <iterator>

using namespace std;

vector<int> randVec(size_t size)
{
	vector<int> v(size);
	// генератор true-random-number
	random_device r;
	// используем лямда-функцию generate()
	// & фиксирует ссылку на локальный объект, чтобы видеть актуальное значение
	generate(v.begin(), v.end(), [&] {return r();});
	return v;
}

int main(int argc, char* argv[])
{
	double start_time, end_time;
	int input = 0;
	
	cout << "введите размер вектора: ";
	cin >> input;
	
	// создание векторов
	vector<int> v(randVec(input));
	vector<int> v1(randVec(input));
	
	// объявим переменные результатов произведения
	int res = 0;
	int res_omp = 0;
	
	// последовательно умножим
	start_time = omp_get_wtime();
	for (int i = 0; i < input; i++)
	{
		res += v[i] * v1[i];
	}
	end_time = omp_get_wtime();
	
	// *** Out
	printf("\nПоследовательная версия:\n");
	printf("Время на скалярное произведение векторов = %f\n", end_time - start_time);
	printf("Скалярное произведение (сумма произведений) = %d\n", res);
	// ***
	
	// параллельно умножим
	start_time = omp_get_wtime();

	// используем parallel for с опцией reduction (суммирование в res_omp)
	#pragma omp parallel for reduction(+:res_omp)
	for (int i = 0; i < input; i++)
	{
		res_omp += v[i] * v1[i];
	}
	end_time = omp_get_wtime();
	
	// *** Out
	printf("\nПараллельная версия:\n");
	printf("Время на скалярное произведение векторов = %f\n", end_time - start_time);
	printf("Скалярное произведение (сумма произведений) = %d\n", res_omp);
	// ***
}
